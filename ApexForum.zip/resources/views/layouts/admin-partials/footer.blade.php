
<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <strong>{{ get_setting('site_name') }}</strong></a> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
