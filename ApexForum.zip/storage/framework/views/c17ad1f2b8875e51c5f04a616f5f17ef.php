<?php echo e(add('registered_successfully')); ?>

<?php /**PATH C:\xampp\htdocs\projects\Tests\ApexForum\resources\views/frontend/phrases.blade.php ENDPATH**/ ?>