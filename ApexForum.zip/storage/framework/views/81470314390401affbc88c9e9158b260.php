
<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <strong><?php echo e(get_setting('site_name')); ?></strong></a> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\projects\Tests\ApexForum\resources\views/layouts/admin-partials/footer.blade.php ENDPATH**/ ?>