<?php

return [

    /*
     * This is the name of the table that will be created by the migration and
     * used by the Reaction model shipped with this package.
     */
    'table_name' => 'reactions',

];
