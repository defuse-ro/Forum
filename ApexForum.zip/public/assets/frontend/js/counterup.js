
$(document).ready(function () {

    "use strict";

    /* ==========================================================================
    Counter Section function by = counterup.min.js
    ========================================================================== */
    $('.counter').counterUp({
        delay: 16,
        time: 5000
    });


});
